/**
 * Clase Ciclista, representa cada ciclista que, junto con su bicicleta,
 * compretira en las diferentes etapas, pero de nivel novato
 */
public class CiclistaNovato extends Ciclista{
    
    public CiclistaNovato(String nombre, Habilidad habilidad, double energia, Equipo e) {
        super(nombre, habilidad, energia, e);
    }
    
    @Override
    public double calcularDestreza() {
        return ((this.habilidad.getHabilidad() + 2) / 120 ) * 10;
    }
}
