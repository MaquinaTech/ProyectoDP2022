public class DatosCampeonatoAbandonos
{
    
    public DatosCampeonatoAbandonos(Organizacion organizacion)
    {
        System.out.println("*********************************************************************************************************");
        System.out.println("*****************ESTA SIMULACIÓN CONCLUYE NORMALMENTE COMPLETANDOSE TODAS LAS CARRERAS PERO CON ABANDONOS*******************");
        System.out.println("*********************************************************************************************************\n");
        
        initData(organizacion);
    }
    
     private void initData(Organizacion organizacion)
    {
        //constructor de etapas pide ( String nombre, double dificultad, double distancia)
    	Etapa etapa1 = new Etapa("sencilla larga",Dificultad.Sencilla,Distancia.Larga);
        Etapa etapa2 = new Etapa("compleja intermedia", Dificultad.Compleja, Distancia.Intermedia);
        Etapa etapa3 = new Etapa("normal intermedia", Dificultad.Normal,Distancia.Intermedia);
        Etapa etapa4 = new Etapa("sencilla intermedia", Dificultad.Sencilla, Distancia.Intermedia);
        Etapa etapa5 = new Etapa("compleja larga", Dificultad.Compleja, Distancia.Larga);
        Etapa etapa6 = new Etapa("normal larga",Dificultad.Normal, Distancia.Larga);
        organizacion.anadirEtapa(etapa1);
        organizacion.anadirEtapa(etapa2);
        organizacion.anadirEtapa(etapa3);
        organizacion.anadirEtapa(etapa4);
        organizacion.anadirEtapa(etapa5);
        organizacion.anadirEtapa(etapa6);
        

        //constructor de equipos pide (String nombre, comparador de ciclistas y si orden ascendente o descendente, comparador de bicicletas y si orden ascendente o descendente)
        Equipo movistarWomen = new Equipo("Movistar Women", new ComparadorHabilidadCiclista(), new ComparadorPesoBicicleta());
        Equipo dSMWomen= new Equipo("DSM Women", new ComparadorEnergiaCiclista(), new ComparadorPesoBicicleta());
        Equipo trekSegafredoWomen = new Equipo("Trek Segafredo Women", new ComparadorHabilidadCiclista().reversed(), new ComparadorPesoBicicleta().reversed());
        
        organizacion.inscribirEquipo(movistarWomen);
        organizacion.inscribirEquipo(trekSegafredoWomen);
        organizacion.inscribirEquipo(dSMWomen);
                
        //constructor de bicicletas pide ( String nombre, double peso)
		dSMWomen.anadirBicicleta(new BicicletaRapida("SCOTT CONTESSA ADDICT eRIDE 15",Peso.Ligera,0.3)); 
        dSMWomen.anadirBicicleta(new BicicletaPrototipo("SCOTT CONTESSA ADDICT 15",Peso.Normal));
        dSMWomen.anadirBicicleta(new BicicletaNormal("SCOTT CONTESSA ADDICT RC 15",Peso.Pesada));
        //constructor de ciclistas pide (String nombre , double habilidad , double energia, Equipo equipo)
		dSMWomen.anadirCiclista(new CiclistaNovato("WIEBES",  Habilidad.Normal, 1190,dSMWomen));
        dSMWomen.anadirCiclista(new CiclistaEstrella("LIPPERT", Habilidad.Lenta, 1160,dSMWomen));
        dSMWomen.anadirCiclista(new CiclistaExperimentado("LABOUS", Habilidad.Buena, 1150,dSMWomen));
     
        //constructor de bicicletas pide ( String nombre, double peso)
		trekSegafredoWomen.anadirBicicleta(new BicicletaNormal("TREK Madone SLR 9 eTap Gen 7",Peso.Ligera));
        trekSegafredoWomen.anadirBicicleta(new BicicletaRapida("TREK Emonda SLR 9 eTap",Peso.Normal,0.5));
        trekSegafredoWomen.anadirBicicleta(new BicicletaPrototipo("TREK Domane SLR 9 eTap Gen 4",Peso.Pesada));
        //constructor de ciclistas pide (String nombre , double habilidad , double energia, Equipo equipo)
		trekSegafredoWomen.anadirCiclista(new CiclistaEstrella("BALSAMO", Habilidad.Lenta,1180,trekSegafredoWomen));
        trekSegafredoWomen.anadirCiclista(new CiclistaExperimentado("LONGO-BORGHINI", Habilidad.Normal,1175,trekSegafredoWomen));
        trekSegafredoWomen.anadirCiclista(new CiclistaNovato("CORDON-RAGOT", Habilidad.Buena, 1120,trekSegafredoWomen));
        
        //constructor de bicicletas pide ( String nombre, double peso)
        movistarWomen.anadirBicicleta(new BicicletaRapida("CANYON Ultimate CFR eTap",Peso.Ligera,0.4));
        movistarWomen.anadirBicicleta(new BicicletaNormal("CANYON Aeroad CF SLX 8 Disc Di2",Peso.Normal));
        movistarWomen.anadirBicicleta(new BicicletaPrototipo("CANYON Endurace CF SLX 9 Di2",Peso.Pesada));
        //constructor de ciclistas pide (String nombre , double habilidad , double energia, Equipo equipo)
        movistarWomen.anadirCiclista(new CiclistaEstrella("VAN VLEUTEN", Habilidad.Buena,1200,movistarWomen));
        movistarWomen.anadirCiclista(new CiclistaExperimentado("NORSGAARD", Habilidad.Normal,1145,movistarWomen));
        movistarWomen.anadirCiclista(new CiclistaNovato("SIERRA", Habilidad.Lenta, 1110,movistarWomen));    

    }

}
