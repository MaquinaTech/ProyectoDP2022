/**
 * Clase Ciclista, representa cada ciclista que, junto con su bicicleta,
 * compretira en las diferentes etapas, pero que es muy popular
 */
public class CiclistaEstrella extends Ciclista implements interfazPopular{

    private int nivelPopularidad;
    
    public CiclistaEstrella(String nombre, Habilidad habilidad, double energia, Equipo e) {
        super(nombre, habilidad, energia, e);
        this.nivelPopularidad = 6;
    }

    @Override
    public double calcularDestreza() {
        return ((this.habilidad.getHabilidad() + 6) / 140 ) * 10;
    }
    
    public void serPopular(double tiempo) {
        if(tiempo<160) {
            this.nivelPopularidad+=4;
            System.out.println("@@@\r\n"
                    + "+++ La popularidad del ciclista " + this.nombre + " ha aumentado  y ahora su nivel de popularidad es de: " + this.nivelPopularidad + " unidades\r\n"
                    + "@@@");
        }
        else {
            this.nivelPopularidad-=1;
            System.out.println("@@@\r\n"
                    + "--- La popularidad del ciclista " + this.nombre + " ha disminuido  y ahora su nivel de popularidad es de: " + this.nivelPopularidad + " unidades\r\n"
                    + "@@@");
        }
    }
    
    @Override
    public boolean correr(Etapa e) throws ExceptionCiclista {
        boolean resCorrer = super.correr(e);
        serPopular(calcularTiempo(e));
        return resCorrer;
    }
    
    @Override
    public String toString() {
        return super.toString() + " <popularidad: " + this.nivelPopularidad + ">";
    }
}
