import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

/**
 * Main simulation class. 
 * First, initial data are loaded. 
 * Then, while not end of the simulation, the actions will be performed.
 *
 * @author profesores DP 
 * @version 22/23
 */
public class CiclismoDemo
{
    
    public static void main(String[] args) throws ExceptionCiclista, IOException {
        Organizacion organizacion=new Organizacion(new ComparadorDificultadEtapa());
        //Descomentar de las dos líneas siguientes, la prueba que se quiera ejecutar
        File ficheroEscritura = new File("salida.log");
        BufferedWriter reset = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ficheroEscritura, false), "UTF8"));
        
        BufferedWriter escritura = null;
        
        try {
			escritura = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream(ficheroEscritura, true), "UTF8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
        
		DatosCampeonatoCompleto initdata = new DatosCampeonatoCompleto(organizacion, escritura);
        //DatosCampeonatoAbandonos initdata = new DatosCampeonatoAbandonos(organizacion); 
        
        organizacion.gestionarCampeonato(escritura);
        
        escritura.close();
        
    }    

}

