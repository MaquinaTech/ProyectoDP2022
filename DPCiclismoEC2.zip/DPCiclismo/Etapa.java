/**
 * Etapa representa al recorrido donde competirán cada jornada los Ciclistas con sus Bicicletas
 */
public class Etapa {
    private String nombre;
    private Dificultad dificultad;
    private Distancia distancia;
    
    /**
     * Default constructor for objects of class Etapa
     */
    public Etapa() {
        this.nombre="Sin asignar";
        this.dificultad=null;
        this.distancia= null;
    }

    /**
     * Parameterized constructor of class Etapa
     */
    public Etapa(String nombre, Dificultad dificultad, Distancia distancia) {
        this.nombre = nombre;
        this.dificultad = dificultad;
        this.distancia = distancia;
    }

    
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the dificultad
     */
    public double getDificultad() {
        return this.dificultad.getDificultad();
    }

    /**
     * @param dificultad the dificultad to set
     */
    public void setDificultad(Dificultad dificultad) {
        this.dificultad = dificultad;
    }

    /**
     * @return the distancia
     */
    public double getDistancia() {
        return distancia.getDistancia();
    }

    /**
     * @param distancia the distancia to set
     */
    public void setDistancia(Distancia distancia) {
        this.distancia = distancia;
    }

    
    /**
     * Muestra la información de la etapa
     */
    @Override
    public String toString() {
        return "<"+ this.getClass().getName().toLowerCase() +":" + this.nombre + "> <dificultad: " + this.dificultad + "> <distancia: " 
                + this.distancia + ")>";
    }
    
}
