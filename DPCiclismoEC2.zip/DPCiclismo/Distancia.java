
public enum Distancia {

	Corta(150), Intermedia(200), Larga(225);

	public final double distancia;
	
	Distancia() {
		this.distancia=0;
	}
	
	Distancia(int i) {
		this.distancia=i;
	}
	
	public double getDistancia() {
		return this.distancia;
	}
	
	public String toString() {
		return this.getClass().getName().toLowerCase() + ":" +  this.name() + " (valor:" + this.distancia + ")";
	}
	
}
