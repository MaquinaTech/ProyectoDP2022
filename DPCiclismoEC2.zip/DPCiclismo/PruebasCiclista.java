import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;

class PruebasCiclista {

	/**
	 * Definición de las fixtures
	 */
	private Ciclista c1;
	private Ciclista c2;
	private Ciclista c3;
	
	private Equipo e1;
	
	private BicicletaNormal b1;
	private BicicletaPrototipo b2;
	private BicicletaRapida b3;
	
	private Etapa etapa1;
	private Etapa etapa2;
	
	public PruebasCiclista() throws ExceptionCiclista {
		e1 = new Equipo("Leones", new ComparadorHabilidadCiclista(), new ComparadorPesoBicicleta());
		
		b1 = new BicicletaNormal("SCOTT CONTESSA ADDICT RC 15",Peso.Pesada);
		b2 = new BicicletaPrototipo("SCOTT CONTESSA ADDICT 15",Peso.Normal);
		b3 = new BicicletaRapida("SCOTT CONTESSA ADDICT eRIDE 15",Peso.Ligera,0.3);
		
		c1 = new CiclistaEstrella("Adri", Habilidad.Lenta, 1100, e1);
		c2 = new CiclistaExperimentado("Jose", Habilidad.Buena, 25, e1);
		c3 = new CiclistaNovato("Joaquín", Habilidad.Normal, 1500, e1);
		
		c1.setBici(b1);
		c2.setBici(b2);
		c3.setBici(b3);
		
		etapa1 = new Etapa("sencilla larga",Dificultad.Sencilla,Distancia.Larga);
        etapa2 = new Etapa("compleja intermedia", Dificultad.Compleja, Distancia.Intermedia);
	}
	
	/**
	 * Sirve para hacer los news a las fixtures.
	 * Es llamado antes de cada prueba.
	 */
	@Before
	public void setUp() {
	}
	
	@Test
	void pruebaCorrer() throws ExceptionCiclista {
		assertEquals(c1.correr(etapa1), false);
		assertEquals(c1.correr(etapa2), false);
		assertEquals(c1.correr(etapa1), false);
		assertEquals(c1.correr(etapa2), false);
		assertEquals(c1.correr(etapa1), true);
		
		assertEquals(c2.correr(etapa1), false);
		assertEquals(c2.correr(etapa2), false);
		assertEquals(c2.correr(etapa1), false);
		assertEquals(c2.correr(etapa2), false);
		assertEquals(c2.correr(etapa1), false);
		assertEquals(c2.correr(etapa2), false);
		assertEquals(c2.correr(etapa1), false);
		assertEquals(c2.correr(etapa2), false);
		assertEquals(c2.correr(etapa1), false);
		assertEquals(c2.correr(etapa2), false);
		assertEquals(c2.correr(etapa1), false);
		assertEquals(c2.correr(etapa2), true);
		
		c3.correr(etapa1);
		assertEquals(c3.getEnergia(), 1351.65, 0.1);
	}

	void pruebaMinutosCarrerasTerminadas() {
		
	}
	
	@After
	public void setDown() {
		
	}
	
}
