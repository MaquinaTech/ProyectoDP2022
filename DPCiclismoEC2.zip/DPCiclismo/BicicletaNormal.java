import java.util.Objects;

/**
 * Clase BicicletaNormal que se encarga de definir una bicicleta normal.
 * 
 * 
 */

public class BicicletaNormal {
    private String nombre;
    private Peso peso;
    
    /**
     * Constructor por defecto de la bicicleta normal.
     * @param no recibe parametros.
     * @return no devuelve nada.
     * Complejidad: O(1)
     */
    public BicicletaNormal() {
        this.nombre="Sin asignar";
        this.peso=null;
    }

    /**
     * Constructor parametrizado de la clase bicicleta normal.
     * @param nombre es el nombre que se le asignará al ciclista.
     * @param peso es el peso que se le asignará al ciclista.
     * Complejidad: O(1)
     */
    public BicicletaNormal(String nombre, Peso peso) {
        this.nombre = nombre;
        this.peso = peso;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the peso
     */
    public double getPeso() {
        return peso.getPeso();
    }

    /**
     * @param peso the peso to set
     */
    public void setPeso(Peso peso) {
        this.peso = peso;
    }

     /**
     * Muestra la informacion de la bicicleta
     * @return String descripcion
     */
    @Override
    public String toString() {
        return "<" + this.getClass().getName() + ": " + nombre + "> <" + peso + ")>";
    }
    
    /**
     * Calcula la velocidad alcanzada por el ciclista en la etapa indicada con esta bicicleta.
     * @param c el ciclista del que se va a calcular la velocidad
     * @param e etapa en la que participa el ciclista
     * @return devuelve el cálculo de la velocidad
     * Complejidad: O(1)
     */
    public double calcularVelocidad(Ciclista c, Etapa e) {
        return (c.getHabilidad()*100)/(this.peso.getPeso() * e.getDificultad());
    }
    
    /**
     * Metodo que calcula el tiempo necesario con una habilidad, dificultad y distancia
     * @return double tiempo necesario
     */
    public double tiempoNecesario(Etapa e, Ciclista c) {
        return ((e.getDistancia() / this.calcularVelocidad(c, e)) * 60);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, peso);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        BicicletaNormal other = (BicicletaNormal) obj;
        return Objects.equals(nombre, other.nombre) && peso == other.peso;
    }
    
    
    
}
