
public enum Peso {
	
	Ligera(7.35), Normal(7.5), Pesada(7.85);

	private final double peso;
	
	Peso() {
		this.peso = 0.0;
	}
	
	Peso(double d) {
		this.peso = d;
	}
	
	public double getPeso() {
		return this.peso;
	}
	
	@Override
	public String toString() {
		return this.getClass().getName().toLowerCase() + ": " +  this.name() + " (valor:" + this.peso + ")";

	}
}
