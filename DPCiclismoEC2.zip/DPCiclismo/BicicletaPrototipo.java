
    /**
    * Clase BicicletaPrototipo que se encarga de definir una bicicleta prototipo.
    */
public class BicicletaPrototipo extends BicicletaNormal{

    public BicicletaPrototipo(String nombre, Peso peso) {
        super(nombre, peso);
    }

    @Override
    public double tiempoNecesario(Etapa e, Ciclista c) {
        return e.getDistancia()/(this.calcularVelocidad(c, e)*c.calcularDestreza());
    }
    
}
