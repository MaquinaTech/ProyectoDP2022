
public interface interfazPopular {
	public void serPopular(double tiempo);
}
