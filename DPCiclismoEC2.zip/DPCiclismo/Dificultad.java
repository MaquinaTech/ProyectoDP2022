
public enum Dificultad {

	Sencilla(0.9), Normal(1.0), Compleja(1.1);

	private final double dificultad;
	
	Dificultad() {
		this.dificultad=0.0;
	}

	Dificultad(double d) {
		this.dificultad=d;
	}
	
	public double getDificultad() {
		return this.dificultad;
	}
	
	public String toString() {
		return this.getClass().getName().toLowerCase() + ":" +  this.name() + " (valor:" + this.dificultad + ")";
	}
	
	
	
}
