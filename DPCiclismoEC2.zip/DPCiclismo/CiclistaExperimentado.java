
/**
 * Clase Ciclista, representa cada ciclista que, junto con su bicicleta,
 * compretira en las diferentes etapas, pero de nivel experimentado
 */
public class CiclistaExperimentado extends Ciclista{

    public CiclistaExperimentado(String nombre, Habilidad habilidad, double energia, Equipo e) {
        super(nombre, habilidad, energia, e);
    }
    
    @Override
    public double calcularDestreza() {
        return ((this.habilidad.getHabilidad() + 4) / 130 ) * 10;
    }
}
