import java.util.Objects;

/**
 * Clase resultado, sirve para gestionar los resultados de los ciclistas en las carreras
 */
public class Resultado {
    private String nombreEtapa;
    private double tiempoEtapa;
    
    /**
     * Default constructor for objects of class Resultado
     */
    public Resultado() {
        this.nombreEtapa="Sin asignar";
        this.tiempoEtapa=0.0;
    }

    /**
     * Parameterized constructor of class Resultado
     */
    public Resultado(String nombreEtapa, double tiempoEtapa) {
        this.nombreEtapa = nombreEtapa;
        this.tiempoEtapa = tiempoEtapa;
    }

    /**
     * @return the nombreEtapa
     */
    public String getNombreEtapa() {
        return nombreEtapa;
    }

    /**
     * @param nombreEtapa the nombreEtapa to set
     */
    public void setNombreEtapa(String nombreEtapa) {
        this.nombreEtapa = nombreEtapa;
    }

    /**
     * @return the tiempoEtapa
     */
    public double getTiempoEtapa() {
        return tiempoEtapa;
    }

    /**
     * @param tiempoEtapa the tiempoEtapa to set
     */
    public void setTiempoEtapa(double tiempoEtapa) {
        this.tiempoEtapa = tiempoEtapa;
    }

    @Override
    public String toString() {
        return "Carrera(" + this.nombreEtapa + ") - Tiempo: " + this.tiempoEtapa + " minutos";
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombreEtapa, tiempoEtapa);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Resultado other = (Resultado) obj;
        return Objects.equals(nombreEtapa, other.nombreEtapa)
                && Double.doubleToLongBits(tiempoEtapa) == Double.doubleToLongBits(other.tiempoEtapa);
    }
    
    
}
