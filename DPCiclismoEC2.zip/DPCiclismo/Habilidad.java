
public enum Habilidad {

	Lenta(4.0), Normal(6.0), Buena(8.0);
	
	private final double habilidad;
	
	Habilidad() {
		this.habilidad=0.0;
	}
	
	Habilidad(double u){
		this.habilidad=u;
	}
	
	public double getHabilidad() {
		return this.habilidad;
	}
	
	@Override
	public String toString() {
		return this.getClass().getName().toLowerCase() + ":" +  this.name() + " (valor:" + this.habilidad + ")";
	}
	
}
