import java.util.Objects;

/**
 * Clase BicicletaRapida que se encarga de definir una bicicleta rápida.
 */

public class BicicletaRapida extends BicicletaNormal{
    
    private double velocidadExtra;
    
    public BicicletaRapida(String nombre, Peso peso, double velocidadExtra) {
        super(nombre, peso);
        this.velocidadExtra = velocidadExtra;
    }

    @Override
    public double calcularVelocidad(Ciclista c, Etapa e) {
        return super.calcularVelocidad(c, e) + velocidadExtra;
    }
    
    @Override
    public String toString() {
        return super.toString() + "<velocidad extra: " + this.velocidadExtra + "> ";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + Objects.hash(velocidadExtra);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        BicicletaRapida other = (BicicletaRapida) obj;
        return Double.doubleToLongBits(velocidadExtra) == Double.doubleToLongBits(other.velocidadExtra);
    }
    
    
    
}
