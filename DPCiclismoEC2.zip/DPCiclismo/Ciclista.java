
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Clase Ciclista, representa cada ciclista que, junto con su bicicleta,
 * compretira en las diferentes etapas
 */
public abstract class Ciclista{
    protected String nombre;
    private BicicletaNormal bici;
    protected Habilidad habilidad;
    private double energia;
    private Map<Integer, Resultado> resultados;
    private Equipo equipo;
    private int cantidadResultados;
    
    /**
     * Default constructor for objects of class Ciclista
     */
    public Ciclista() {
        this.nombre="Sin asignar";
        this.bici=null;
        this.habilidad=null;
        this.energia=0.0;
        this.resultados= new HashMap<Integer, Resultado>();
        this.equipo=null;
        this.cantidadResultados=0;
    }

    /**
     * Parameterized constructor of class Ciclista
     */
    public Ciclista(String nombre, Habilidad habilidad, double energia) {
        this.nombre = nombre;
        this.bici=null;
        this.habilidad = habilidad;
        this.energia = energia;
        this.resultados= new HashMap<Integer, Resultado>();
        this.equipo=null;
        this.cantidadResultados=0;
    }

    /**
     * Parameterized constructor of class Ciclista
     */
    public Ciclista(String nombre, Habilidad habilidad, double energia, Equipo e) {
        this.nombre=nombre;
        this.bici=null;
        this.habilidad=habilidad;
        this.energia=energia;
        this.resultados= new HashMap<Integer, Resultado>();
        this.equipo=e;
        this.cantidadResultados=0;
    }

    public abstract double calcularDestreza();
    
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the bici
     */
    public BicicletaNormal getBici() {
        return bici;
    }

    /**
     * @param bici the bici to set
     * @throws ExceptionCiclista 
     */
    public void setBici(BicicletaNormal bici) throws ExceptionCiclista {
        if(bici==null) {
            throw new ExceptionCiclista("Estás colocando una bicicleta nula al ciclista " + this.nombre);
        }
        this.bici = bici;
    }

    /**
     * @return the habilidad
     */
    public double getHabilidad() {
        return habilidad.getHabilidad();
    }

    /**
     * @param habilidad the habilidad to set
     */
    public void setHabilidad(Habilidad habilidad) {
        this.habilidad = habilidad;
    }

    /**
     * @return the energia
     */
    public double getEnergia() {
        return energia;
    }

    /**
     * @param energia the energia to set
     */
    public void setEnergia(double energia) {
        this.energia = energia;
    }

    /**
     * @return the equipo
     * @throws ExceptionCiclista 
     */
    public Equipo getEquipo() throws ExceptionCiclista {
        if(this.equipo==null) {
            throw new ExceptionCiclista("El equipo está a null en el ciclista " + this.nombre);
        }
        return equipo;
    }

    /**
     * @param equipo the equipo to set
     */
    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    /**
     * Metodo que muestra la informacion del ciclista
     * @return String descripcion
     */
    @Override
    public String toString() {
        return "<" + this.getClass().getName() + ":" + nombre + "> <energía: " + energia + "> <" + habilidad + "> <tiempo acumulado sin abandonar: " + this.tiempoTerminadas() + "> <abandonado:" + haAbandonado() + ">";
    }
   
    /**
     * Método que devuelve true en caso de que la energía de un ciclista sea
     * inferior a 0 y false en caso contrario
     * @return boolean res
     */
    public boolean haAbandonado() {
        boolean res;
        if(this.energia<0)
            res = true;
        else
            res = false;
        return res;
    }
    
    /**
     * Método que anota los resultados de una etapa
     * @return no devuelve nada
     */
    public void anotarResultado(String nombreEtapa, double resultadoEtapa) throws ExceptionCiclista {
        if(this.resultados==null) {
            throw new ExceptionCiclista("la lista resultados en la clase Ciclista está a null, olvidaste hacerle el new en el constructor");
        }
        Resultado r = new Resultado(nombreEtapa, resultadoEtapa);
        this.resultados.put(cantidadResultados, r);
        cantidadResultados++;
    }
    
    /**
     * Método que muestra los resultados de una etapa
     * @return no devuelve nada
     */
    public void mostrarResultados() {
        for(int i=0; i<this.cantidadResultados; i++) {
            System.out.println(this.resultados.get(i));
        }
    }
    
    /**
     * Método que devuelve el número de etapas totales 
     * @return numero de etapas
     */
    public int numeroEtapas() {
        return this.resultados.size();
    }
    
    /**
     * Método que devuelve el número de etapas terminadas 
     * @return numero de etapas terminadas (int cont)
     */
    public int numeroEtapasTerminadas() {
        int cont=0;
        Resultado r;
        for (int i=0; i<this.cantidadResultados; i++) {
            r = this.resultados.get(i);
            if(r.getTiempoEtapa()>0) {
                cont++;
            }
        }
        return cont;
    }
    
    /**
     * Método que devuelve el tiempo de las etapas terminadas 
     * @return tiempo de etapas terminadas (double res)
     */
    public double tiempoTerminadas() {
        double res=0;
        Resultado r;
        for (int i=0; i<this.cantidadResultados; i++) {
            r = this.resultados.get(i);
            if(r.getTiempoEtapa()>0) {
                res+=r.getTiempoEtapa();
            }
        }
        return res;
    }
    
    /**
     * Método que devuelve el nombre de la etaoa en la que hay abandonos 
     * @return string nombreEtapa
     */
    public String etapaAbandono() {
        String nombreEtapa = null;
        Resultado r;
        boolean enc=false;
        int i=0;
        while(i<this.resultados.size()&&!enc) {
            r=this.resultados.get(i);
            if(r.getTiempoEtapa()<0) {
                nombreEtapa = r.getNombreEtapa();
                enc=true;
            }
            else {
                i++;
            }
        }
        return nombreEtapa;
    }
    
    /**
     * Método que devuelve el último tiempo conseguido en una etapa 
     * @return Resultado r
     */
    public double ultimoTiempoConseguido() {
        Resultado r = this.resultados.get(resultados.size()-1);
        return r.getTiempoEtapa();
    }
    
    /**
     * Método que devuelve el tiempo medio en una etapa 
     * @return double media/cont
     */
    public double mediaTiempo() {
        double media=0;
        double cont=0;
        Resultado r;
        for (int i=0; i<this.cantidadResultados; i++) {
            r = this.resultados.get(i);
            media+=r.getTiempoEtapa();
            cont++;
        }
        if(cont==0)
            cont++;
        return media/cont;
    }
    
    /**
     * Método que calcula el tiempo que se ha tardado en realizar una etapa 
     * @return double tiempo 
     */
    public double calcularTiempo(Etapa e) {
        return this.bici.tiempoNecesario(e, this);
    }

    @Override
    public int hashCode() {
        return Objects.hash(habilidad, nombre);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Ciclista other = (Ciclista) obj;
        return habilidad == other.habilidad && Objects.equals(nombre, other.nombre);
    }

    public boolean correr(Etapa e) throws ExceptionCiclista {
        if(this.energia<=0) {
            throw new ExceptionCiclista("Estás haciendo correr al ciclista " + this.nombre + " y tiene energía: " + this.energia);
        }
        
        boolean abandonos = false;
        System.out.println(this + " con bicicleta");
        System.out.println(getBici() + " en etapa " + e.getNombre());
        System.out.println("+++ Con estas condiciones el ciclista "+ this.nombre + " con la bicicleta " + getBici().getNombre() + " alcanza una velocidad de "+ getBici().calcularVelocidad(this, e) +" km/hora +++");
        
        this.energia = this.energia - calcularTiempo(e);
        
        if(this.energia<0) {
            System.out.println("¡¡¡ El ciclista " + this.nombre + " se quedó sin energia a falta de " + (0-this.energia) + " minutos para terminar !!!");
            System.out.println("¡¡¡ En el momento de quedarse sin energia llevaba en carrera " + (calcularTiempo(e) + this.energia) + " minutos !!!");
            anotarResultado(e.getNombre(), this.energia);
            abandonos=true;
        }
        else {
            System.out.println("+++ " + this.nombre + " termina la etapa en " + calcularTiempo(e) + " minutos +++");
            anotarResultado(e.getNombre(), calcularTiempo(e));
        }
        
        System.out.println("+++ La energía del ciclista " + this.nombre + " tras la carrera es " + Math.round(this.energia*100.0)/100.0 + " +++");
        System.out.println("@@@");
        return abandonos;
    }
    
}
