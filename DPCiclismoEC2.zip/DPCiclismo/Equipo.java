import java.util.ArrayList;
import java.util.Comparator;

/**
 * Equipos en los que competiran los ciclistas en cada etapa
 */
public class Equipo {
    private String nombre;
    private ArrayList<Ciclista> listaCiclistas;
    private ArrayList<Ciclista> listaAbandonados;
    private ArrayList<BicicletaNormal> listaBicicletas;
    private Comparator<Ciclista> comparadorCiclista;
    private Comparator<BicicletaNormal> comparadorBicicleta;
    
    /**
     * Default constructor for objects of class Equipo
     */
    public Equipo() {
        this.nombre="";
        this.listaAbandonados = new ArrayList<Ciclista>();
        this.listaBicicletas = new ArrayList<BicicletaNormal>();
        this.listaCiclistas = new ArrayList<Ciclista>();
    }

    /**
     * Parameterized constructor of class Equipo
     */
    public Equipo(String nombre) {
        this.nombre = nombre;
        this.listaAbandonados = new ArrayList<Ciclista>();
        this.listaBicicletas = new ArrayList<BicicletaNormal>();
        this.listaCiclistas = new ArrayList<Ciclista>();
    }

    /**
     * Second parameterized constructor of class Equipo
     */
    public Equipo(String nombre, Comparator<Ciclista> cc, Comparator<BicicletaNormal> cb) {
        this.nombre = nombre;
        this.listaAbandonados = new ArrayList<Ciclista>();
        this.listaBicicletas = new ArrayList<BicicletaNormal>();
        this.listaCiclistas = new ArrayList<Ciclista>();
        this.comparadorCiclista = cc;
        this.comparadorBicicleta = cb;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    /**
     * Metodo que ordena los ciclistas segun el comparador
     */
    public void ordenarCiclistas() {
        this.listaCiclistas.sort(comparadorCiclista);
    }
    
    /**
     * Metodo que ordena las biciletas segun el comparador
     */
    public void ordenarBicicletas() {
        this.listaBicicletas.sort(comparadorBicicleta);
    }
    
    /**
     * Metodo que devuelve el tiempo total de loc ciclistas del equipo
     * @return double tiempoTotal Tiempo total de los ciclistas
     */
    public double getTiempoTotalCiclistas() {
        double tiempoTotal=0;
        for (Ciclista c : listaCiclistas) {
            tiempoTotal+=c.tiempoTerminadas();
        }
        return tiempoTotal;
    }
    
    /**
     * Metodo que retorna un ciclista con una bicicleta
     * @return Ciclista
     */
    public Ciclista enviarCiclista() throws ExceptionCiclista {
        Ciclista c = this.listaCiclistas.get(0);
        BicicletaNormal b = this.listaBicicletas.get(0);
        this.listaBicicletas.remove(0);
        this.listaCiclistas.remove(0);
        c.setBici(b);
        return c;
    }
    
    /**
     * Metodo que devuelve si en una lista hay ciclistas o no
     * @return boolean hay ciclistas
     */
    public boolean hayCiclistas() {
        return !this.listaCiclistas.isEmpty();
    }
    
    /**
     * Metodo que retorna y elimina una bicicleta del equipo
     * @return Bicileta
     */
    public BicicletaNormal enviarBicicleta() {
        BicicletaNormal b = this.listaBicicletas.get(0);
        this.listaBicicletas.remove(0);
        return b;
    }

    /**
     * Metodo para añadir una Bicileta al Equipo
     * @param Bicicleta b
     */
    public void anadirBicicleta(BicicletaNormal b) {
        this.listaBicicletas.add(b);
        this.ordenarBicicletas();
    }

    /**
     * Metodo para añadir un Ciclista al Equipo
     * @param Ciclista c
     */
    public void anadirCiclista(Ciclista c) {
        if(c.getEnergia()<0) {
            this.listaAbandonados.add(c);
        }
        else {
            this.listaCiclistas.add(c);
            this.ordenarCiclistas();
        }
    }

    @Override
    public String toString() {
        String cadena = "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n";
        cadena+="%%% " + this.nombre.toUpperCase() + " %%% Media Minutos de Ciclistas sin abandonar " + this.mediaTiempoCiclistas() + " %%%\n";
        
        return cadena;
    }
    
    /**
     * Metodo que muestra los ciclistas de un equipo
     */
    public void mostrarCiclistasEquipo() {
        for (Ciclista c : listaCiclistas) {
            System.out.println(c);
        }
        for (Ciclista c : listaAbandonados) {
            System.out.println(c);
        }
    }
    
    /**
     * Metodo que calcula la media de tiempo realizada por los ciclistas
     * @return double tiempo/cont
     */
    public double mediaTiempoCiclistas() {
        double tiempo=0, cont=0;
        for (Ciclista c : listaCiclistas) {
            tiempo+=c.tiempoTerminadas();
            cont++;
        }
        return tiempo/cont;
    }

    /**
     * Metodo que dice si hay ciclistas que hayan abandonado o no
     * @return boolean hay abandonados
     */
    public boolean hayCiclistasAbandonados() {
        return !this.listaAbandonados.isEmpty();
    }

    /**
     * Metodo que retorna y elimina un ciclista del campeonato
     * @return Bicileta
     */
    public Ciclista enviarCiclistaAbandonado() {
        return this.listaAbandonados.remove(0);
    }
}
